#ifndef REMOTE_WINDOW_PROTO_H
#define REMOTE_WINDOW_PROTO_H

#ifdef __cplusplus
extern "C" {
#endif

int WINDOW_main(HINSTANCE, int, USHORT);

#ifdef __cplusplus
}	/* extern "C" */
#endif

#endif	/* REMOTE_WINDOW_PROTO_H */
